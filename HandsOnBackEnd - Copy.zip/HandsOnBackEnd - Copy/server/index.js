const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
const app = express();
const PORT = 3004;


mongoose.connect('mongodb://localhost:27017/chatAppRevisi')
  .then(() => console.log("Connected to MongoDB"))
  .catch(err => console.error("MongoDB connection error:", err));

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));
app.use(express.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, '..', 'client')));

const MessageSchema = new mongoose.Schema(
  {
    id: {
      fromMe: { type: Boolean},
      remote: { type: String},
      id: { type: String},
      _serialized: { type: String }
    },
    body: { type: String},
    type: { type: String},
    from: { type: String},
    to: { type: String},
    timestamp: { type: Number}
  },
  { id: false } // Disable automatic id virtual creation
);

const Message = mongoose.model('messages', MessageSchema);
//const User = mongoose.model("user", UserSchema);

app.get('/', async(req, res) => {
  res.sendFile(path.join(__dirname, '..', 'client', 'index_coba.html'));
})

app.get("/messages", async (req, res) => {
  try {
      const allMessages = await Message.find({}).select('-_id id body type from to timestamp'); 
      console.log(`Found ${allMessages.length} messages`); // Log the number of messages found

      return res.json(allMessages); // Return all messages including their messages array
  } catch (error) {
      console.error("Error fetching messages:", error); // Log any errors
      return res.status(500).send(error); // Send a 500 status code for server errors
  }
});




app.get("/messages/:senderId", async (req, res) => {
  try {
      const id = req.params.senderId;
      const message = await Message.findOne({ senderId: id });
  
      
      if (!message) {
          return res.status(404).json({
              error: "Gada datanya wak", 
          });
      }
      
      return res.json(message); 
  } catch (error) {
      return res.status(500).send(error);
  }
});



app.post('/post', async (req, res) => {
  try {
    const { body } = req.body;  // Extract message from form data
    
    if (!body) {
      return res.status(400).send("Message body is required");
    }

    const newMessage = new Message({ 
      id: {
        fromMe: true
      },
      body,
      timestamp: Date.now()
    });
    await newMessage.save();  // Save to MongoDB
    
    console.log("Message saved:", newMessage);
    res.status(201).send("Message saved successfully!");
  } catch (error) {
    console.error("Error saving message:", error);
    res.status(500).send("Internal server error");
  }
});


app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
